package job.project.com.recyclego.modelo;

public class Comment {
}
