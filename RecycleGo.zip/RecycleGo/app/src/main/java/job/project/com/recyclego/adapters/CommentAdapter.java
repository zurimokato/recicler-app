package job.project.com.recyclego.adapters;

public class CommentAdapter {
}
